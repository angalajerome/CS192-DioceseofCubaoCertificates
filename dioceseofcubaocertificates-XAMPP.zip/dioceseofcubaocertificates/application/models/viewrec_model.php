<?php
class viewrec_model extends CI_Model
{
	function __construct() 
	{
		parent::__construct();
	}
	function getRecBapts($data)
	{
		$q = "SELECT * FROM bapts where ((MONTH(registered) <=".$data['endMonth']." AND YEAR(registered)  =".$data['endYear'].") OR (YEAR(registered) <".$data['endYear'].")) AND".
			"((MONTH(registered) >=".$data['startMonth']." AND YEAR(registered) = ".$data['startYear'].") OR (YEAR(registered) >".$data['startYear']."));";
		$query = $this->db->query($q);
		return $query;
	}

	function getRecConfs($data)
	{
		$q = "SELECT * FROM confs where ((MONTH(registered) <=".$data['endMonth']." AND YEAR(registered)  =".$data['endYear'].") OR (YEAR(registered) <".$data['endYear'].")) AND".
			"((MONTH(registered) >=".$data['startMonth']." AND YEAR(registered) = ".$data['startYear'].") OR (YEAR(registered) >".$data['startYear']."));";
		$query = $this->db->query($q);
		return $query;
	}
}
?>