<!doctype html>
<?php echo link_tag('assets/css/bootstrap.css')?>
<?php echo link_tag('assets/css/singlePageTemplate.css')?>
<html lang="en-US">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Roman Catholic Diocese of Cubao Certificates Database</title>
<link rel="shortcut icon" href="<?php echo base_url('assets/images/logo.png'); ?>">
<!-- Main Stylesheet -->
<link rel="stylesheet" href="css/singlePageTemplate.css" type="text/css">
<link rel="stylesheet" href="css/bootstrap.css">
<!-- Login Template -->
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.-->
<script>var __adobewebfontsappname__="dreamweaver"</script>
<script src="http://use.edgefonts.net/source-sans-pro:n2:default.js" type="text/javascript"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!-- Main Container -->
<div class="container"> 
	<div class="row">
		<header>
			<h1 align="center">
				<br>
				<img class="logo" src="<?php echo base_url('assets/images/logo.png'); ?>" alt="Logo" style="width:85px;height:85px;">
				<font class="title" size="6">ROMAN CATHOLIC DIOCESE OF CUBAO</font>
				<br>
				<font class="title" size="5">Certificates Database</font>
			</h1>
		</header>
	</div>
  	<!-- User Information and Logout Section -->	
	<div class="row">
		<nav class="navbar navbar-default">
			<div class="container-fluid">
 				<!-- User Information Section -->
  				<p class="navbar-text">Welcome, <?php echo($username);?> from <?php echo($parishname);?>!</p>
  				<!-- Logout Section -->
				<button type="submit" onclick="location.href='<?php echo base_url('index.php/Logout_controller'); ?>';" class="btn btn-danger navbar-btn pull-right"><span class="glyphicon glyphicon-log-out"></span> Log Out</button>
			</div>
		</nav>
 	</div>
 	<!-- View Records and Statistics Section -->
 	<div class="row">
		<!-- Go back to Check Statistics Page Section -->
		<br>
		<a href="<?php echo base_url('index.php/Statistics_controller/index')?>" class="btn btn-default btn-block" role="button"><span class="glyphicon glyphicon-arrow-left"></span> Go Back to Check Statistics Page</a>
		<br>
		<br>
		<!-- Displaying Records From Month Year to Month Year Section -->
		 <?php
		// echo($dates['startMonth']." ");
		// echo($dates['startYear']." ");
		// echo($dates['endMonth']." ");
		// echo($dates['endYear']." ");
		// $dateStart = mktime(1, 0, 0, $dates['startMonth'], 1, $dates['startYear']);
		// if ($dates['endMonth'] == 2)
		// {
			// $a = 28;
		// }
		// else if ($dates['endMonth'] < 8 && $dates['endMonth'] % 2 == 0)
		// {
			// $a = 30;
		// }
		// else if ($dates['endMonth'] < 8 && $dates['endMonth'] % 2 != 0)
		// {
			// $a = 31;
		// }
		// else if ($dates['endMonth'] >= 8 && $dates['endMonth'] % 2 == 0)
		// {
			// $a = 31;
		// }
		// else if ($dates['endMonth'] >= 8 && $dates['endMonth'] % 2 != 0)
		// {
			// $a = 30;
		// }
		// $dateEnd = mktime(23, 59, 59, $dates['endMonth'], $a, $dates['endYear']);
		// echo(date("Y-m-d h:i:sa      ",$dateStart));
		// echo(date("Y-m-d h:i:sa      ",$dateEnd));
		?>
		<label>Baptismal Certificates</label>
		<table class="table table-striped table-bordered table-condensed">
			<thead>
				<tr>
					<th>Name</th>
					<th>Date Registered</th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ($recBapts->result_array() as $row)
				{
					if ($parishcode == 9999 || $parishcode == $row['bParishCode'])
					{
						echo("<tr>");
						echo("<td>".$row['lastName'].",".$row['firstName']."</td>");
						echo("<td>".$row['registered']."</td>");
						echo("</tr>");
					}
				}
				?>
			</tbody>
		</table>
		
		<label>Confirmation Certificates</label>
		<table class="table table-striped table-bordered table-condensed">
			<thead>
				<tr>
					<th>Name</th>
					<th>Date Registered</th>
				</tr>
			</thead>
			<tbody>
				<?php
				
				foreach ($recConfs->result_array() as $row)
				{
					if ($parishcode == 9999 || $parishcode == $row['cParishCode'])
					{
						echo("<tr>");
						echo("<td>".$row['lastName'].",".$row['firstName']."</td>");
						echo("<td>".$row['registered']."</td>");
						echo("</tr>");
					}
				}
				?>
			</tbody>
		</table>
	</div>
	<br>
 	<br>
</div>
<!-- Main Container Ends -->
</body>
</html>
